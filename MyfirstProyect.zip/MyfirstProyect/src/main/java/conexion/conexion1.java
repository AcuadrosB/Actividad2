package conexion;

 import java.sql.*;
 class conexion1  {
  public static void main (String args []) throws SQLException
  {    

    DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());

    Connection conn = DriverManager.getConnection
          ("jdbc:oracle:thin:@localhost:1521:xe", "HR", "ANDRES123");
         // driver@machineName:port:SID      ,  USUARIO, Password

    Statement stmt = conn.createStatement();
    ResultSet rset = 
              stmt.executeQuery("select * from REGISTRO_USUARIO");
    		//stmt.executeQuery("INSERT INTO CARGO VALUES(2,'SECRETARIA','ACTIVO')");
    
    while (rset.next()) {
      System.out.println (rset.getString(1)); 
    System.out.println (rset.getString(2)); 
    System.out.println (rset.getString(3)); 
    System.out.println (rset.getString(4)); // Print col 1
    }
     
    
    stmt.close();
    
  }
 }
